# Independent builder realization of SPEC-FLAG-WORLD-FIRST-TICK-001 (V1/V2).
# Written from the spec readings (FT v0.1.1 :159-199), D2 README, and the cited D2
# definition lines (tick.py 29, 36-38, 40-60, 94, 95-110). Does NOT import or call
# tick.py, flag_rederive.py, author_vectors.mjs, or any Codex realization.
# Authoring support / independent witness. Not a runtime.
import json, sys, hashlib, itertools, collections

NO, THIS = "NO", "THIS"

def canon(o):  # FT :160-161 reference observation encoding
    return json.dumps(o, sort_keys=True, separators=(",", ":")).encode("utf-8")
def H(o):      # D2 :36 — sha256 of sorted-key compact JSON, lowercase hex
    return hashlib.sha256(canon(o)).hexdigest()

def T(x):      # flags as hashable tuples: (vertex, (e0,e1), (t0,t1,t2))
    return (x[0], tuple(x[1]), tuple(x[2]))
def L(f):      # back to JSON lists
    return [f[0], list(f[1]), list(f[2])]

class World:
    def __init__(self, flag_list):
        self.FLAGS = [T(f) for f in flag_list]              # order := D2 lexicographic (FT :189)
        assert self.FLAGS == sorted(self.FLAGS), "field is not in lexicographic incidence order"
        assert len(self.FLAGS) == 480
        self.FSET = set(self.FLAGS)
        sites = {f[0] for f in self.FLAGS}; edges = {f[1] for f in self.FLAGS}; triads = {f[2] for f in self.FLAGS}
        assert (len(sites), len(edges), len(triads)) == (42, 120, 80), (len(sites), len(edges), len(triads))
        # overlaps: two flags that agree in two coordinates and differ in the third (FT :54, :71)
        idx = collections.defaultdict(list)
        for f in self.FLAGS:
            idx[("ve", f[0], f[1])].append(f); idx[("vt", f[0], f[2])].append(f); idx[("et", f[1], f[2])].append(f)
        pairs = set()
        for lst in idx.values():
            for a, b in itertools.combinations(lst, 2):
                pairs.add((min(a, b), max(a, b)))
        self.PAIRS = sorted(pairs)
        assert len(self.PAIRS) == 720, len(self.PAIRS)
        self.tri_of_edge = collections.defaultdict(set)
        for f in self.FLAGS: self.tri_of_edge[f[1]].add(f[2])

    def agreement(self, field):   # SAME iff equal readings on the overlap (FT :54)
        return {p: field[p[0]] == field[p[1]] for p in self.PAIRS}

    def body(self, field, ents):  # D2 :37 state body; D2 :103 body
        return {"field": [[L(f), field[f]] for f in self.FLAGS],
                "entities": {k: L(v) for k, v in sorted(ents.items())}}

    def genesis(self, kappa, E0):  # D2 :47-53; FT :51
        kappa = T(kappa); assert kappa in self.FSET
        field = {f: NO for f in self.FLAGS}
        ents = {k: T(v) for k, v in E0.items()}
        for pos in ents.values(): field[pos] = THIS
        rec = {"kind": "GENESIS", "kappa": L(kappa), "resolution_m": 2, "governance_type": "anchored",
               "state_hash": H(self.body(field, ents))}
        rec["link"] = H(rec)
        return {"field": field, "entities": ents, "chain": [rec]}

    def completions(self, frm, kind, target):  # offered lifts (README T3: site 2, triad 2, edge 1)
        v, e, t = frm; out = []
        if kind == "site":
            if target in e and target != v:
                for t2 in sorted(self.tri_of_edge[e]): out.append((target, e, t2))
        elif kind == "edge":
            te = tuple(target)
            if v in te and set(te) <= set(t) and te != e: out.append((v, te, t))
        elif kind == "triad":
            tt = tuple(target)
            if v in tt and tt != t:
                for e2 in sorted(itertools.combinations(tt, 2)):
                    if v in e2 and (v, e2, tt) in self.FSET: out.append((v, e2, tt))
        return [f for f in out if f in self.FSET]

    def reading(self, field, frm, to):  # D2 :55-59
        succ = dict(field); succ[frm] = NO; succ[to] = THIS
        before = self.agreement(field); after = self.agreement(succ)
        return {"walls_after": sum(1 for p in after if not after[p]),
                "discharged": sum(1 for p in after if after[p] and not before[p]),
                "opened": sum(1 for p in after if before[p] and not after[p])}, succ, before, after

    def tick(self, S, entity, kind, target, lift):
        frm = T(lift["from"]); to = T(lift["to"]); via = T(lift["via"])
        assert S["entities"][entity] == frm, "lift.from is not the entity's position"
        assert via == frm, "via must be the predecessor flag"
        assert to in self.completions(frm, kind, target), "selected lift is not an offered completion"
        rd, succ, before, after = self.reading(S["field"], frm, to)
        assert rd == lift["reading"], ("lift reading NOT_SAME", rd, lift["reading"])
        ents = dict(S["entities"]); ents[entity] = to
        receipt = {"discharged": sorted([[L(p[0]), L(p[1])] for p in after if after[p] and not before[p]]),
                   "opened":     sorted([[L(p[0]), L(p[1])] for p in after if before[p] and not after[p]])}
        what = {"entity": entity, "whence": L(frm), "lift": lift}
        rec = {"kind": "TICK", "prev": S["chain"][-1]["link"], "what": what, "receipt_hash": H(receipt),
               # RECEIPT_READING_001 (FT :167-171): receipt_reading replaces receipt_empty
               "receipt_reading": THIS if (receipt["discharged"] or receipt["opened"]) else NO,
               "state_hash": H(self.body(succ, ents))}
        rec["link"] = H(rec)
        assert rec["prev"] == S["chain"][-1]["link"]
        return {"field": succ, "entities": ents, "chain": S["chain"] + [rec]}, receipt

def run(inp):
    W = World([x[0] for x in inp["initial_state"]["field"]])
    # FT :172-173: initial_state must be the genesis produced from kappa/E0
    G = W.genesis(inp["kappa"], inp["E0"])
    given = inp["initial_state"]
    assert W.body(G["field"], G["entities"]) == {"field": given["field"], "entities": given["entities"]}, "genesis field NOT_SAME initial_state"
    assert G["chain"] == given["chain"], "genesis chain NOT_SAME initial_state.chain"
    S2, receipt = W.tick(G, inp["entity"], inp["kind"], inp["target"], inp["selected_lift"])
    state = W.body(S2["field"], S2["entities"]); state["chain"] = S2["chain"]
    return {"receipt": receipt, "state": state}   # FT :164-166 output projection

if __name__ == "__main__":
    inp = json.load(open(sys.argv[1]))
    out = canon(run(inp))
    sys.stdout.buffer.write(out)
