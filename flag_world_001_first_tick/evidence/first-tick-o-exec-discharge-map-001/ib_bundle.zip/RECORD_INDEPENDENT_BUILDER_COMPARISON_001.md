# RECORD — O_INDEPENDENT_BUILDER_COMPARISON: an independent first-tick realization reproduces V1 and V2 byte for byte

```text
STATUS     := PROPOSED discharge of O_INDEPENDENT_BUILDER_COMPARISON (FT v0.1.1 :156; v0.1.3 terminal). Devon DECIDE / PROMOTE.
BUILDER    := Claude, this session, 2026-10-22 17:30–17:45 ET. Python 3 (-I). Authoring support / independent witness; not a runtime.
OBJECT     := SPEC-FLAG-WORLD-FIRST-TICK-001 v0.1.1 (73429D78…), frozen vectors V1 / V2.
REALIZATION:= first_tick_ib.py  sha256 E02C90DE0F22D6F736FB4C00C64B37D588F70CF01E38BF1C4532300581606E0B  (≈110 lines)
```

## Result

| Vector | Input (sha256) | My output (sha256, bytes) | Frozen expected (sha256, bytes) | Verdict |
| --- | --- | --- | --- | --- |
| V1 | 28093717ACC694FACC3B635701A22AFF37DDB09FB0447774BACC700647F262BE | 69786966E9B5D66A2078D29C43E1F1511545786AB07BF562E37D91205085B588, 33,563 | 69786966E9B5D66A2078D29C43E1F1511545786AB07BF562E37D91205085B588, 33,563 | SAME |
| V2 | DC46E239B9D693AF25DC3D7005718060230D31AC9CA057F7ECCCF73968AA2C8E | BD0492B4CAC427432CC3251EB27FC997C0D5EFF2862ECBC10A89B9AC19F1AD0F, 33,548 | BD0492B4CAC427432CC3251EB27FC997C0D5EFF2862ECBC10A89B9AC19F1AD0F, 33,548 | SAME |

Both committed outputs are byte-identical to the frozen expected bytes, and therefore to the GPU realization's
promoted outputs (RECEIPT_PROMOTE_FIRST_TICK_CONFORM_V1_V2_001, commit bccd23f4). Three routes now agree:
hand derivation (authoring pass), GPU realization (Codex), this realization (Claude).

## Independence — exactly what was and was not read

READ (as source definitions the spec itself cites):
- FT v0.1.1 :159–199 (encoding, output projection, genesis/tick record rules, RECEIPT_READING_001, local names).
- D2/README.md (545D755A…) in full: world counts, stage separation, acceptance T1–T6 (lift counts site 2 / triad 2 / edge 1).
- D2/tick.py (535535DA…) ONLY the cited definition lines and their immediate neighbours: :29 (FLAGS order), :36–38 (H, state_body, agreement over PAIR_OVERLAPS), :40–60 (genesis, _reading), :94 (the `what` record shape), :95–110 (_promote_state record shape, execute).
- The input vectors (data) and the expected vectors (for the byte comparison only, after my outputs were produced).

NOT READ / NOT USED:
- D2/tick.py :61–93 (propose, decide, promote bodies), PAIR_OVERLAPS construction, flag_rederive.py.
- author_vectors.mjs, revise.mjs, any Codex realization, kernel, matcher, prefill or GPU artifact.

CONSTRUCTED INDEPENDENTLY (and checked against the data):
- The 480 flags, 42 sites, 120 edges, 80 triads: taken from the input field (input data) and verified in lexicographic order.
- The 720 overlaps: flag pairs equal in two coordinates and differing in one (FT :54, :71), found by 3-key hashing. Count verified 720.
- Offered completions per kind (site / edge / triad). Counts verified 2 / 1 / 2 against README T3.
- Genesis from κ/E0 (FT :51, D2 :47–53) regenerated and compared SAME to the supplied initial_state, field and chain link (abc6919e…).
- The tick: successor field, discharged / opened / walls, receipt, `what`, receipt_reading (RECEIPT_READING_001), state_hash, link.

## Negative checks (the realization is a check, not a pass-through)
Rejected: a `to` that is not an offered completion; `via` ≠ `from`; a declared lift reading that does not match the
computed reading; an initial_state that is not the genesis of κ/E0; a kind that does not match the target. All five → AssertionError.

## Scope
- Discharges the "independent" part of O_INDEPENDENT_BUILDER_COMPARISON for the first-tick realization on the D2-labelled vectors.
- Shares with the authoring pass the spec's own cited definitions (encoding, record shapes). Independence is from the authoring/checking
  pass and from the GPU realization, not from the promoted definitions, which is what the obligation asks.
- Does not touch the J17 hardware-genesis world, placement beyond J17, or marker routes.
