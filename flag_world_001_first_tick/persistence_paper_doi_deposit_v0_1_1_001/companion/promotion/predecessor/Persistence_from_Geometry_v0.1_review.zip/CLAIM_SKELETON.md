# Paper two construction skeleton

STATUS := PROPOSED_DRAFT
G := paper_one + finding_0_1_5 + finding_0_1_6 + receipts_026_036 + amendment_037 + readings_040 + qualification_038_042
S := fixed_incidence ; two_readings ; offered_supports ; whole_changed_set ; ancestry
F := witnessed_persistence ; contextual_retention ; refinement_correspondence ; deterministic_snapshot_successor

```text
THIS(q) := (incidence, readings, offered_supports)
W(q) := NOT_SAME_overlaps(q)
D(q,a) := changed_flags(q,a)
boundary(D) := overlaps(ONE_endpoint_INSIDE_D)

EVERY a:
  discharged(q,a) := boundary(D) INTERSECT W(q)
  opened(q,a) := boundary(D) OUTSIDE W(q)
  STRICT(q,a) IF_THEN boundary(D) NOT_SAME empty AND boundary(D) INSIDE W(q)
  BECAUSE ONE_endpoint_changed IF_THEN overlap_reading_NOT_SAME

SAND(q) IF_THEN W(q) NOT_SAME empty AND K(q) SAME empty
  NOT_SAME incidence_alone
  GOES_WITH readings AND offered_supports

RULE_A:
  triangle : NO(retention)
  shared_edge_composition : CAN(retention)
  witness := authoring_support_census ; NOT_SAME GPU_receipt

RULE_C:
  pairs_4 : 60_shed ; 420_held
  witness_60_exits := GPU_targeted_receipts
  witness_420_complete_K := read_only_bound_incidence
  NOT_SAME arbitrary_field_footprint_rule

RULE_D:
  SAME(hole, ancestry)
  NOT_SAME(exterior)
  NOT_SAME(receipt_30_10, receipt_20_0)
  BECAUSE containing_support_cuts_exterior_class

REFINEMENT:
  q_child := q_parent COMPOSE pi
  single_site_12_to_48 : K_singleton_to_empty
  NOT_SAME image(site), preimage(site)
  nested_24_96_1800_to_96_384_7200 : K_empty_to_empty
  prediction_64_walls_30_20 SAME native_receipt
  NO(general_retention_transport_claim)
  NO(vertical_world_transition_claim)

SNAPSHOT_EFFECT_SET:
  DOMAIN := whole_site AND fixed_incidence AND bound_closed_levels_1_2_4
  concurrent OR absorbed ; NO(conflict_in_domain)
  JOINT_APPLICATION(E(q_n)) -> q_next
  receipt := direct_wall_set_difference(q_n,q_next)
  LINK -> renewed_PROPOSE(q_next)
  NO(current_tick_result_observation)

QUALIFICATION:
  GPU_semantics_038 : witnessed_cases_and_controls
  canonical_W38_042 : eight_conditions_discharged
  effect_comparison_and_write_assembly : OPEN_PAUSED
  NO(full_038_qualification_claim)

DELIVERY := manuscript + PDF + evidence_ledger + claim_review
NO(promotion, commit, push, world_transition, GPU_execution)
```

The prose follows these subjects. The receipt ledger binds numerical claims; the finding is a synthesis and correction record. Later promotion of the snapshot-effect amendment supersedes the finding's historical open multi-member operand without editing the finding.
