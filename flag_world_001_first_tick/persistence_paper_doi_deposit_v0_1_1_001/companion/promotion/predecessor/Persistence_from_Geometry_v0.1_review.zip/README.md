# Persistence from Geometry

**Context, Refinement and Deterministic Change**

Devon A. Generally · MetaCortex Dynamics LLC · Paper two · Draft v0.1 · 1 November 2026

[Read the paper](output/pdf/Persistence_from_Geometry_v0.1.pdf) · [Editable manuscript](PERSISTENCE_FROM_GEOMETRY_v0.1.md) · [Evidence ledger](EVIDENCE_LEDGER.json)

The paper develops contextual retention, ancestry-dependent pair outcomes, refinement-created retention, and the scoped deterministic snapshot successor. It leads with the controlled contrast: the same enclosed region dissolves in one surrounding field and remains protected in another.

## Evidence subjects

- Exhaustive GPU receipts for the listed configuration families at (1,0) and (2,0): 146 and 656 fields respectively.
- 89 targeted GPU receipts at (4,0), including all 60 shedding-pair face offers, all 20 interior-triple face offers, the nested-field contrast and composite cases.
- Complete read-only computations over the bound (4,0) incidence, separately scoped from those targeted GPU receipts.
- Full offered-family GPU evaluation of the stated nested (8,0) configuration, with the prior prediction retained beside the result.
- Scoped snapshot-effect derivation and bounded GPU demonstrations; canonical site-reading join qualification is distinguished from the remaining full-application binding.

The 21 byte-identical compact evidence copies are in `evidence/`. The ledger records original paths, hashes, sizes, publication availability and claim scopes. It does not duplicate the large raw execution archive or claim to re-run its experiments.

## Draft construction and review

[CLAIM_SKELETON.md](CLAIM_SKELETON.md) precedes the prose. [CLAIM_REVIEW.json](CLAIM_REVIEW.json) records the source and scope review. `BUILD_RECORD.json` and `PDF_QA_RECORD.json` bind the typesetting and page review. `DRAFT_MANIFEST.json` binds the delivered files.

The PDF uses the publication workflow from paper one. `build_paper.py` and `qa_pdf.py` are document-production utilities; they are not MaL execution sources. They use ReportLab, pypdf, pdfplumber, Pillow and Poppler, with the host's Georgia, Segoe UI, Consolas and Cambria fonts. Font files are not distributed.

## Work boundary

038 remains **PAUSED**. The W38_SITE_READING_JOIN binding and qualification stand. Effect comparison and write assembly remain open; no work on them was performed for this paper.

The manuscript is a draft, not an attestation or promotion. This task performs no GPU execution, world transition, repository commit, push or publication. Finding v0.1.6 remains PROPOSED. Its historical open multi-member operand is read alongside the subsequently promoted snapshot-effect amendment, without editing either source.

The existing paper-one DOI is retained. The new compact evidence companion has no new public deposit yet; its local package identity is not a publication claim.
