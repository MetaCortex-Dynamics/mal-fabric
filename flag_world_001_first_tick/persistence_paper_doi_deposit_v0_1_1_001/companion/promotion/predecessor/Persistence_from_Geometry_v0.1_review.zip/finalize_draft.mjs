import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

// Draft-document custody only. Does not execute MaL, use the GPU, or write upstream evidence.
const root = path.dirname(fileURLToPath(import.meta.url));
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex').toUpperCase();
const inspect = relative => {
  const bytes = fs.readFileSync(path.join(root, relative));
  return { path: relative.replaceAll('\\', '/'), bytes: bytes.length, sha256: digest(bytes) };
};
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8').replace(/^\uFEFF/, ''));
const write = (file, value) => fs.writeFileSync(path.join(root, file), JSON.stringify(value, null, 2) + '\n');
const source = inspect('PERSISTENCE_FROM_GEOMETRY_v0.1.md');
const pdf = inspect('output/pdf/Persistence_from_Geometry_v0.1.pdf');
const build = read('BUILD_RECORD.json');
const qa = read('PDF_QA_RECORD.json');
if (build.source.sha256 !== source.sha256 || build.pdf.sha256 !== pdf.sha256 || qa.pdf.sha256 !== pdf.sha256) {
  throw new Error('Document/source/render identities NOT_SAME; finalization withheld.');
}
const evidence = read('EVIDENCE_LEDGER.json');
for (const entry of evidence.entries) {
  const copy = inspect(entry.relative_copy);
  const original = fs.readFileSync(entry.original_path);
  if (copy.sha256 !== entry.sha256 || copy.bytes !== entry.bytes || digest(original) !== entry.sha256) {
    throw new Error('Evidence copy NOT_SAME: ' + entry.id);
  }
}
const review = {
  schema: 'PAPER_TWO_CLAIM_REVIEW_001',
  at: new Date().toISOString(),
  manuscript: source,
  reading: 'IF_THEN_WITH_STATED_EVIDENCE_SCOPES',
  construction: 'CLAIM_SKELETON.md was written before manuscript prose.',
  independent_source_reviews: [
    { subject: 'Sections 2-6 and 8', sources: 'Finding 0.1.6 and actual closed 026/036 records', result: 'Counts and evidence scopes SAME', repairs: ['Context sentence retains the same hole class.', 'Conclusion preserves the nonempty-boundary condition.'] },
    { subject: 'Sections 7-10', sources: 'Promoted 037 clauses, current 040 mapping, native 038 and canonical join 042', result: 'Scope correspondence IF_THEN', repairs: ['Joint changed-flag assignment, complete successor, candidate and LINK distinguished.', 'Singleton replay states field/witness/receipt/pair bytes, not whole-link identity.', 'Equivalent offers are not a distinct proper-absorption GPU fixture.', 'Flat seed-row enumeration reversal is the stated scope.'] }
  ],
  evidence_boundaries: {
    levels_1_2: 'Exhaustive GPU receipts for stated families, not every possible field.',
    level_4: '89 targeted GPU receipts; complete classifications retain read-only bound-incidence scope.',
    level_8: 'Full 33256-raw-assignment receipt for one nested transported field.',
    refinement_single_site: 'Read-only carrier-to-carrier result, not a world refinement.',
    proper_absorption: 'Scoped mathematical construction; zero positive distinct fixtures in bounded GPU search.',
    implementation_042: 'Site-reading join only; effect comparison and write assembly OPEN and PAUSED.'
  },
  evidence_original_and_copy_count: evidence.entries.length,
  evidence_original_and_copy_comparison: 'SAME',
  preservation: { work_038: 'PAUSED', GPU: 'NOT_RUN', world_transition: 'NOT_RUN', source_records: 'UNCHANGED', promotion: 'NOT_RUN', commit: 'NOT_RUN', push: 'NOT_RUN', publication: 'NOT_RUN' }
};
write('CLAIM_REVIEW.json', review);
const top = ['README.md', 'PERSISTENCE_FROM_GEOMETRY_v0.1.md', 'CLAIM_SKELETON.md', 'EVIDENCE_LEDGER.json', 'CLAIM_REVIEW.json', 'BUILD_RECORD.json', 'PDF_QA_RECORD.json', 'build_paper.py', 'qa_pdf.py', 'finalize_draft.mjs', 'output/pdf/Persistence_from_Geometry_v0.1.pdf'];
const files = [...top, ...evidence.entries.map(e => e.relative_copy)].map(inspect);
write('DRAFT_MANIFEST.json', {
  schema: 'PERSISTENCE_PAPER_TWO_DRAFT_MANIFEST_001',
  at: new Date().toISOString(),
  status: 'DRAFT_NOT_PROMOTED',
  title: 'Persistence from Geometry: Context, Refinement and Deterministic Change',
  files,
  total_bytes: files.reduce((sum, file) => sum + file.bytes, 0),
  evidence_copies: evidence.entries.length,
  PDF_pages: build.pdf.pages,
  scope: 'Authored paper and compact evidence companion. Large raw archive and temporary page images are not packaged. No experiment or upstream corpus modification.'
});
process.stdout.write(JSON.stringify({ source, pdf, pages: build.pdf.pages, evidence_copies: evidence.entries.length, manifest: inspect('DRAFT_MANIFEST.json') }, null, 2) + '\n');
