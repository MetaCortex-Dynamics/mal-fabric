# Persistence from Geometry v0.1.1

Context, Refinement and Deterministic Change

Devon A. Generally · MetaCortex Dynamics LLC · Draft for review

[PDF](output/pdf/Persistence_from_Geometry_v0.1.1.pdf) · [Manuscript](PERSISTENCE_FROM_GEOMETRY_v0.1.1.md) · [Version custody](VERSION_CUSTODY.json) · [Finding review](FINDING_016_REVIEW.md)

v0.1.1 names the reviewed revision unambiguously. Its manuscript body is SAME as review 002 after the exact version-line substitution. VERSION_CUSTODY.json records both earlier manuscript/PDF hash pairs, including the initially reviewed PDF EAA4A5CF…37A6459. DRAFT_MANIFEST.json binds the current bytes. Earlier versions remain unchanged.

The four review fixes and the finding annotations are retained in REVIEW_REVISION_002.json and FINDING_016_REVIEW.json. PREDECESSOR_CLAIM_REVIEW.json is explicitly the earlier manuscript's review, not a claim that its source hash identifies v0.1.1. EVIDENCE_LEDGER.json maps the 22 byte-identical compact records; large raw readbacks are not bundled.

No promotion, repository commit, push or world transition. 038 remains paused. Upload to a private review Page is file delivery only, not publication.

The Python files are document-production utilities, outside the MaL execution path. The PDF is rebuilt from the named manuscript, with its author and edition metadata.
